"""
Модель для предсказания цен финансовых инструментов
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Union, Tuple
import joblib
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import logging

logger = logging.getLogger(__name__)

class PricePredictionModel:
    """
    Модель для прогнозирования цен финансовых инструментов
    """
    
    def __init__(self, model_type: str = 'random_forest', params: Dict = None):
        """
        Инициализация модели прогнозирования
        
        Args:
            model_type: Тип модели ('random_forest', 'gradient_boosting', 'linear', 'ridge')
            params: Словарь с параметрами модели
        """
        self.model_type = model_type
        self.params = params if params is not None else {}
        self.model = self._create_model()
        self.is_fitted = False
        logger.info(f"Инициализирована модель прогнозирования цен типа {model_type}")
    
    def _create_model(self):
        """
        Создает модель машинного обучения выбранного типа
        
        Returns:
            Объект модели
        """
        if self.model_type == 'random_forest':
            return RandomForestRegressor(**self.params)
        elif self.model_type == 'gradient_boosting':
            return GradientBoostingRegressor(**self.params)
        elif self.model_type == 'linear':
            return LinearRegression(**self.params)
        elif self.model_type == 'ridge':
            return Ridge(**self.params)
        else:
            raise ValueError(f"Неизвестный тип модели: {self.model_type}")
    
    def fit(self, X: Union[pd.DataFrame, np.ndarray], y: Union[pd.Series, np.ndarray]):
        """
        Обучает модель на предоставленных данных
        
        Args:
            X: Признаки для обучения
            y: Целевые значения
        """
        self.model.fit(X, y)
        self.is_fitted = True
        logger.info(f"Модель {self.model_type} обучена на {X.shape[0]} примерах")
        
        # Если модель поддерживает важность признаков, сохраняем их
        if hasattr(self.model, 'feature_importances_'):
            if isinstance(X, pd.DataFrame):
                self.feature_importances = pd.Series(
                    self.model.feature_importances_,
                    index=X.columns
                ).sort_values(ascending=False)
            else:
                self.feature_importances = self.model.feature_importances_
    
    def predict(self, X: Union[pd.DataFrame, np.ndarray]) -> np.ndarray:
        """
        Делает прогноз на основе входных данных
        
        Args:
            X: Признаки для прогнозирования
            
        Returns:
            Массив прогнозов
        """
        if not self.is_fitted:
            raise ValueError("Модель не обучена. Сначала вызовите метод fit().")
        
        return self.model.predict(X)
    
    def evaluate(self, X: Union[pd.DataFrame, np.ndarray], y: Union[pd.Series, np.ndarray]) -> Dict[str, float]:
        """
        Оценивает качество модели на тестовых данных
        
        Args:
            X: Признаки для оценки
            y: Истинные значения
            
        Returns:
            Словарь с метриками качества
        """
        if not self.is_fitted:
            raise ValueError("Модель не обучена. Сначала вызовите метод fit().")
        
        predictions = self.predict(X)
        
        return {
            'mse': mean_squared_error(y, predictions),
            'rmse': np.sqrt(mean_squared_error(y, predictions)),
            'mae': mean_absolute_error(y, predictions),
            'r2': r2_score(y, predictions)
        }
    
    def save(self, filepath: str):
        """
        Сохраняет модель на диск
        
        Args:
            filepath: Путь для сохранения
        """
        model_data = {
            'model': self.model,
            'model_type': self.model_type,
            'params': self.params,
            'is_fitted': self.is_fitted,
        }
        
        if hasattr(self, 'feature_importances'):
            model_data['feature_importances'] = self.feature_importances
        
        joblib.dump(model_data, filepath)
        logger.info(f"Модель сохранена в {filepath}")
    
    @classmethod
    def load(cls, filepath: str) -> 'PricePredictionModel':
        """
        Загружает модель с диска
        
        Args:
            filepath: Путь к сохраненной модели
            
        Returns:
            Загруженная модель
        """
        model_data = joblib.load(filepath)
        
        instance = cls(model_type=model_data['model_type'], params=model_data['params'])
        instance.model = model_data['model']
        instance.is_fitted = model_data['is_fitted']
        
        if 'feature_importances' in model_data:
            instance.feature_importances = model_data['feature_importances']
        
        logger.info(f"Модель загружена из {filepath}")
        return instance