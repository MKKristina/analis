"""
Модуль прогнозирования цен с использованием нейронных сетей
"""

import os
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import pandas as pd
import logging
from typing import Dict, List, Optional, Union, Tuple
from datetime import datetime, timedelta
from sklearn.preprocessing import MinMaxScaler
import joblib

logger = logging.getLogger(__name__)

class LSTM(nn.Module):
    """
    LSTM модель для прогнозирования временных рядов
    """
    
    def __init__(self, input_size, hidden_layer_size=100, num_layers=2, output_size=1, dropout=0.2):
        super(LSTM, self).__init__()
        
        self.hidden_layer_size = hidden_layer_size
        self.num_layers = num_layers
        
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_layer_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0
        )
        
        self.dropout = nn.Dropout(dropout)
        self.linear = nn.Linear(hidden_layer_size, output_size)
    
    def forward(self, x):
        lstm_out, _ = self.lstm(x)
        
        # Берем только последний выход
        out = self.dropout(lstm_out[:, -1, :])
        output = self.linear(out)
        
        return output

class PredictionModel:
    """
    Класс для прогнозирования цен на основе ML моделей
    """
    
    def __init__(self, gpu_manager=None):
        """
        Инициализация модели прогнозирования
        
        Args:
            gpu_manager: Менеджер GPU ресурсов
        """
        self.gpu_manager = gpu_manager
        self.device = self.gpu_manager.get_available_device() if gpu_manager else torch.device('cpu')
        self.models_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'saved_models')
        
        # Создаем директорию для сохранения моделей, если она не существует
        os.makedirs(self.models_dir, exist_ok=True)
        
        logger.info(f"Модель прогнозирования инициализирована, устройство: {self.device}")
    
    def _prepare_data(self, df: pd.DataFrame, sequence_length: int = 50):
        """
        Подготовка данных для модели
        
        Args:
            df: DataFrame с данными
            sequence_length: Длина последовательности
            
        Returns:
            X, y, scalers
        """
        # Выбор признаков
        features = ['close', 'volume']
        
        # Добавляем технические индикаторы, если они есть
        for col in df.columns:
            if col in ['rsi_14', 'macd', 'bb_upper', 'bb_lower', 'atr_14', 'adx', 'cci']:
                features.append(col)
        
        # Нормализация данных
        feature_scaler = MinMaxScaler(feature_range=(-1, 1))
        target_scaler = MinMaxScaler(feature_range=(-1, 1))
        
        # Нормализуем цену закрытия для целевой переменной (только close)
        target_data = df[['close']].values
        target_scaled = target_scaler.fit_transform(target_data)
        
        # Нормализуем признаки
        feature_data = df[features].values
        feature_scaled = feature_scaler.fit_transform(feature_data)
        
        # Создаем последовательности
        X, y = [], []
        
        for i in range(len(feature_scaled) - sequence_length):
            X.append(feature_scaled[i:i + sequence_length])
            y.append(target_scaled[i + sequence_length])
        
        # Преобразуем в numpy массивы
        X = np.array(X)
        y = np.array(y)
        
        return X, y, feature_scaler, target_scaler, features
    
    def train(self, df: pd.DataFrame, symbol: str, interval: str, sequence_length: int = 50, 
             epochs: int = 100, batch_size: int = 32):
        """
        Обучение модели
        
        Args:
            df: DataFrame с данными
            symbol: Символ
            interval: Интервал
            sequence_length: Длина последовательности
            epochs: Количество эпох
            batch_size: Размер батча
            
        Returns:
            Статус обучения
        """
        try:
            # Подготовка данных
            X, y, feature_scaler, target_scaler, features = self._prepare_data(df, sequence_length)
            
            # Разделение на обучающую и валидационную выборки (80/20)
            train_size = int(len(X) * 0.8)
            X_train, X_val = X[:train_size], X[train_size:]
            y_train, y_val = y[:train_size], y[train_size:]
            
            # Преобразование в тензоры PyTorch
            X_train = torch.tensor(X_train, dtype=torch.float32).to(self.device)
            y_train = torch.tensor(y_train, dtype=torch.float32).to(self.device)
            X_val = torch.tensor(X_val, dtype=torch.float32).to(self.device)
            y_val = torch.tensor(y_val, dtype=torch.float32).to(self.device)
            
            # Создание модели
            input_size = X_train.shape[2]  # Количество признаков
            model = LSTM(input_size=input_size, hidden_layer_size=100, num_layers=2).to(self.device)
            
            # Определение функции потерь и оптимизатора
            criterion = nn.MSELoss()
            optimizer = optim.Adam(model.parameters(), lr=0.001)
            
            # Обучение модели
            train_losses = []
            val_losses = []
            best_val_loss = float('inf')
            
            for epoch in range(epochs):
                model.train()
                
                # Разделение на батчи
                for i in range(0, len(X_train), batch_size):
                    batch_X = X_train[i:i+batch_size]
                    batch_y = y_train[i:i+batch_size]
                    
                    # Обнуление градиентов
                    optimizer.zero_grad()
                    
                    # Прямой проход
                    outputs = model(batch_X)
                    
                    # Вычисление потерь
                    loss = criterion(outputs, batch_y)
                    
                    # Обратное распространение
                    loss.backward()
                    
                    # Оптимизация весов
                    optimizer.step()
                
                # Оценка на валидационном наборе
                model.eval()
                with torch.no_grad():
                    val_outputs = model(X_val)
                    val_loss = criterion(val_outputs, y_val)
                
                # Сохранение лучшей модели
                if val_loss.item() < best_val_loss:
                    best_val_loss = val_loss.item()
                    model_path = os.path.join(self.models_dir, f'{symbol}_{interval}_lstm.pth')
                    scalers_path = os.path.join(self.models_dir, f'{symbol}_{interval}_scalers.pkl')
                    
                    # Сохранение модели и скейлеров
                    torch.save(model.state_dict(), model_path)
                    joblib.dump({
                        'feature_scaler': feature_scaler,
                        'target_scaler': target_scaler,
                        'features': features
                    }, scalers_path)
                
                # Логирование прогресса
                if (epoch + 1) % 10 == 0:
                    logger.info(f'Epoch [{epoch+1}/{epochs}], Val Loss: {val_loss.item():.4f}')
                
                train_losses.append(loss.item())
                val_losses.append(val_loss.item())
            
            return {
                "status": "success",
                "symbol": symbol,
                "interval": interval,
                "epochs": epochs,
                "final_val_loss": val_losses[-1],
                "best_val_loss": best_val_loss,
                "model_path": model_path,
                "training_time": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
        except Exception as e:
            logger.error(f"Ошибка обучения модели: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def predict(self, df: pd.DataFrame, sequence_length: int = 50, prediction_horizon: int = 12) -> Dict:
        """
        Прогнозирование цен
        
        Args:
            df: DataFrame с данными
            sequence_length: Длина последовательности
            prediction_horizon: Горизонт прогнозирования
            
        Returns:
            Прогноз
        """
        try:
            # Получаем символ и интервал из индекса (предполагая, что они есть в имени файла или метаданных)
            symbol = df.name if hasattr(df, 'name') else "unknown"
            interval = "unknown"
            
            # Пытаемся найти модель
            model_path = os.path.join(self.models_dir, f'{symbol}_{interval}_lstm.pth')
            scalers_path = os.path.join(self.models_dir, f'{symbol}_{interval}_scalers.pkl')
            
            # Если модели нет, пытаемся найти любую подходящую модель
            if not os.path.exists(model_path):
                logger.warning(f"Модель для {symbol}_{interval} не найдена, используем общую модель")
                model_files = [f for f in os.listdir(self.models_dir) if f.endswith('_lstm.pth')]
                
                if not model_files:
                    logger.error("Модели не найдены. Необходимо обучить модель")
                    return {}
                
                # Берем первую доступную модель
                model_path = os.path.join(self.models_dir, model_files[0])
                symbol_interval = model_files[0].replace('_lstm.pth', '')
                scalers_path = os.path.join(self.models_dir, f'{symbol_interval}_scalers.pkl')
            
            # Проверяем наличие скейлеров
            if not os.path.exists(scalers_path):
                logger.error(f"Файл скейлеров для {symbol}_{interval} не найден")
                return {}
            
            # Загрузка скейлеров и списка признаков
            scalers_data = joblib.load(scalers_path)
            feature_scaler = scalers_data['feature_scaler']
            target_scaler = scalers_data['target_scaler']
            features = scalers_data['features']
            
            # Подготовка данных для прогноза
            # Проверка наличия всех необходимых признаков в данных
            for feature in features:
                if feature not in df.columns:
                    logger.warning(f"Признак {feature} отсутствует в данных")
                    return {}
            
            feature_data = df[features].values
            feature_scaled = feature_scaler.transform(feature_data)
            
            # Берем последние sequence_length точек для прогнозирования
            input_sequence = feature_scaled[-sequence_length:].reshape(1, sequence_length, -1)
            input_tensor = torch.tensor(input_sequence, dtype=torch.float32).to(self.device)
            
            # Загрузка модели
            input_size = input_tensor.shape[2]  # Количество признаков
            model = LSTM(input_size=input_size, hidden_layer_size=100, num_layers=2).to(self.device)
            model.load_state_dict(torch.load(model_path, map_location=self.device))
            model.eval()
            
            # Выполняем прогноз на несколько шагов вперед
            predictions = []
            current_input = input_tensor.clone()
            latest_date = df.index[-1]
            
            with torch.no_grad():
                for i in range(prediction_horizon):
                    # Получаем прогноз
                    output = model(current_input)
                    
                    # Преобразуем обратно в исходный масштаб
                    pred_price = target_scaler.inverse_transform(output.cpu().numpy())[0][0]
                    
                    # Сохраняем прогноз
                    next_date = latest_date + self._get_time_delta(interval, i+1)
                    predictions.append({
                        'date': next_date.strftime('%Y-%m-%d %H:%M:%S'),
                        'close_pred': float(pred_price)
                    })
                    
                    # Для следующего шага прогноза обновляем входные данные
                    if i < prediction_horizon - 1:
                        # Получаем последнюю реальную точку
                        last_real_point = feature_scaled[-1].copy()
                        
                        # Обновляем цену закрытия в этой точке на наш прогноз
                        # Предполагаем, что close - первый признак в списке features
                        close_idx = features.index('close')
                        last_real_point[close_idx] = output.cpu().numpy()[0][0]
                        
                        # Создаем новую входную последовательность, сдвигая окно на один шаг
                        new_sequence = np.vstack([feature_scaled[-(sequence_length-1):], last_real_point])
                        current_input = torch.tensor(new_sequence.reshape(1, sequence_length, -1), 
                                                    dtype=torch.float32).to(self.device)
            
            return predictions
            
        except Exception as e:
            logger.error(f"Ошибка прогнозирования: {str(e)}")
            return {}
    
    def _get_time_delta(self, interval: str, steps: int = 1) -> timedelta:
        """
        Получение временного интервала в зависимости от интервала свечей
        
        Args:
            interval: Интервал свечей
            steps: Количество шагов
            
        Returns:
            Временной интервал
        """
        if interval == '1':
            return timedelta(minutes=steps)
        elif interval == '5':
            return timedelta(minutes=5*steps)
        elif interval == '15':
            return timedelta(minutes=15*steps)
        elif interval == '30':
            return timedelta(minutes=30*steps)
        elif interval == '60':
            return timedelta(hours=steps)
        elif interval == '240':
            return timedelta(hours=4*steps)
        elif interval == 'D':
            return timedelta(days=steps)
        elif interval == 'W':
            return timedelta(weeks=steps)
        elif interval == 'M':
            return timedelta(days=30*steps)
        else:
            return timedelta(hours=steps)
    
    def update_models(self, symbols: Optional[List[str]] = None, force: bool = False) -> Dict:
        """
        Обновление моделей
        
        Args:
            symbols: Список символов для обновления
            force: Принудительное обновление
            
        Returns:
            Статус обновления
        """
        results = {
            "updated": [],
            "failed": [],
            "skipped": []
        }
        
        # Если список символов не указан, берём все доступные модели
        if not symbols:
            model_files = [f for f in os.listdir(self.models_dir) if f.endswith('_lstm.pth')]
            symbols = list(set([f.split('_')[0] for f in model_files]))
        
        # TODO: Добавить код получения данных и обновления моделей для каждого символа
        
        return results