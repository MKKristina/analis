"""
Модуль для предобработки данных перед машинным обучением
"""

import numpy as np
import pandas as pd
from typing import Tuple, List, Dict, Optional
from sklearn.preprocessing import StandardScaler, MinMaxScaler, RobustScaler

def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Очищает данные от выбросов и NaN значений
    
    Args:
        df: DataFrame с исходными данными
        
    Returns:
        Очищенный DataFrame
    """
    # Создаем копию, чтобы не модифицировать исходные данные
    clean_df = df.copy()
    
    # Заполнение NaN значений методом вперед (берем предыдущее значение)
    clean_df = clean_df.fillna(method='ffill')
    
    # Если после этого все еще есть NaN в начале данных, заполняем нулями
    clean_df = clean_df.fillna(0)
    
    # Обработка выбросов методом винзоризации (обрезания экстремальных значений)
    # Для каждой колонки с числовыми данными
    for col in clean_df.select_dtypes(include=[np.number]).columns:
        # Рассчитываем квантили
        q1 = clean_df[col].quantile(0.01)  # 1% квантиль
        q3 = clean_df[col].quantile(0.99)  # 99% квантиль
        
        # Заменяем значения за пределами квантилей
        clean_df.loc[clean_df[col] < q1, col] = q1
        clean_df.loc[clean_df[col] > q3, col] = q3
    
    return clean_df


def normalize_features(df: pd.DataFrame, method: str = 'standard', 
                     return_scaler: bool = False) -> Tuple[pd.DataFrame, Optional[object]]:
    """
    Нормализует признаки для машинного обучения
    
    Args:
        df: DataFrame с признаками
        method: Метод нормализации ('standard', 'minmax', 'robust')
        return_scaler: Возвращать ли объект scaler для обратного преобразования
        
    Returns:
        Кортеж (нормализованный DataFrame, scaler или None)
    """
    # Выбираем объект нормализации в зависимости от метода
    if method == 'standard':
        scaler = StandardScaler()
    elif method == 'minmax':
        scaler = MinMaxScaler()
    elif method == 'robust':
        scaler = RobustScaler()
    else:
        raise ValueError(f"Неизвестный метод нормализации: {method}. "
                         "Доступные методы: 'standard', 'minmax', 'robust'")
    
    # Создаем копию, чтобы не модифицировать исходные данные
    normalized_df = df.copy()
    
    # Нормализуем только числовые колонки
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    normalized_values = scaler.fit_transform(df[numeric_cols])
    
    # Заменяем значения в исходном DataFrame
    normalized_df[numeric_cols] = normalized_values
    
    if return_scaler:
        return normalized_df, scaler
    else:
        return normalized_df, None


def create_sequences(data: np.ndarray, sequence_length: int) -> Tuple[np.ndarray, np.ndarray]:
    """
    Создает последовательности для обучения рекуррентных нейронных сетей
    
    Args:
        data: Массив данных
        sequence_length: Длина последовательности
        
    Returns:
        Кортеж (X_sequences, y_sequences)
    """
    X, y = [], []
    
    for i in range(len(data) - sequence_length):
        X.append(data[i:i+sequence_length])
        y.append(data[i+sequence_length])
    
    return np.array(X), np.array(y)


def train_test_time_split(df: pd.DataFrame, test_size: float = 0.2, 
                        validation_size: float = 0.1) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Разделяет временной ряд на обучающую, валидационную и тестовую выборки
    
    Args:
        df: DataFrame с данными
        test_size: Размер тестовой выборки (доля)
        validation_size: Размер валидационной выборки (доля)
        
    Returns:
        Кортеж (train_df, val_df, test_df)
    """
    # Определяем точки разделения
    n = len(df)
    test_start = int(n * (1 - test_size))
    val_start = int(test_start * (1 - validation_size))
    
    # Разделяем данные
    train_df = df.iloc[:val_start].copy()
    val_df = df.iloc[val_start:test_start].copy()
    test_df = df.iloc[test_start:].copy()
    
    return train_df, val_df, test_df