"""
Управление GPU ресурсами для ML моделей
"""

import os
import logging
import torch
import numpy as np

logger = logging.getLogger(__name__)

class GPUManager:
    """
    Класс для управления GPU ресурсами и оптимизации вычислений
    """
    
    def __init__(self, use_gpu: bool = True, memory_fraction: float = 0.8):
        """
        Инициализация менеджера GPU
        
        Args:
            use_gpu: Включить использование GPU
            memory_fraction: Доля памяти GPU для использования (от 0 до 1)
        """
        self.use_gpu = use_gpu and torch.cuda.is_available()
        self.memory_fraction = min(max(memory_fraction, 0.1), 1.0)
        self.device = None
        self.initialize()
    
    def initialize(self):
        """
        Инициализация GPU и настройка параметров
        """
        try:
            if self.use_gpu:
                # Проверка доступных GPU
                gpu_count = torch.cuda.device_count()
                
                if gpu_count > 0:
                    # Выбираем GPU с наибольшим объёмом свободной памяти
                    free_memory = []
                    
                    for i in range(gpu_count):
                        # Освобождаем неиспользуемую память
                        torch.cuda.empty_cache()
                        
                        # Проверяем доступную память
                        total_memory = torch.cuda.get_device_properties(i).total_memory
                        reserved_memory = torch.cuda.memory_reserved(i)
                        allocated_memory = torch.cuda.memory_allocated(i)
                        free_memory.append(total_memory - reserved_memory - allocated_memory)
                    
                    # Выбираем GPU с максимальной свободной памятью
                    selected_gpu = np.argmax(free_memory)
                    
                    # Устанавливаем устройство
                    self.device = torch.device(f'cuda:{selected_gpu}')
                    torch.cuda.set_device(selected_gpu)
                    
                    # Ограничиваем использование памяти
                    if torch.cuda.is_available():
                        # Для PyTorch достаточно правильно управлять тензорами
                        logger.info(f"Установлено GPU устройство: {torch.cuda.get_device_name(selected_gpu)}")
                        logger.info(f"Доступная память GPU: {free_memory[selected_gpu]/1024**3:.2f} GB")
                else:
                    logger.warning("GPU не обнаружены. Используется CPU.")
                    self.use_gpu = False
                    self.device = torch.device('cpu')
            else:
                logger.info("Использование GPU отключено. Используется CPU.")
                self.device = torch.device('cpu')
        
        except Exception as e:
            logger.error(f"Ошибка инициализации GPU: {str(e)}")
            logger.info("Используется CPU в качестве запасного варианта.")
            self.use_gpu = False
            self.device = torch.device('cpu')
    
    def get_available_device(self):
        """
        Получение текущего устройства для вычислений
        
        Returns:
            Устройство для вычислений (torch.device)
        """
        return self.device
    
    def is_gpu_available(self):
        """
        Проверка доступности GPU
        
        Returns:
            True, если GPU доступен и включен, иначе False
        """
        return self.use_gpu
    
    def memory_stats(self):
        """
        Получение статистики использования памяти
        
        Returns:
            Словарь со статистикой использования памяти
        """
        stats = {
            "using_gpu": self.use_gpu,
            "device": str(self.device)
        }
        
        if self.use_gpu:
            device_idx = self.device.index
            stats.update({
                "gpu_name": torch.cuda.get_device_name(device_idx),
                "total_memory_gb": torch.cuda.get_device_properties(device_idx).total_memory / (1024**3),
                "allocated_memory_gb": torch.cuda.memory_allocated(device_idx) / (1024**3),
                "reserved_memory_gb": torch.cuda.memory_reserved(device_idx) / (1024**3),
                "max_memory_gb": torch.cuda.max_memory_allocated(device_idx) / (1024**3)
            })
        
        return stats
    
    def optimize_for_inference(self):
        """
        Оптимизация для режима вывода (inference)
        """
        if self.use_gpu:
            # Освобождаем неиспользуемую память
            torch.cuda.empty_cache()
            
            # Устанавливаем режим cudnn.benchmark для оптимизации
            torch.backends.cudnn.benchmark = True