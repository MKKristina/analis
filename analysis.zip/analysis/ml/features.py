"""
Модуль для извлечения признаков из финансовых данных
для машинного обучения
"""

import numpy as np
import pandas as pd
from typing import List, Dict, Union, Optional

def extract_basic_features(df: pd.DataFrame, window_sizes: List[int] = [5, 14, 30]) -> pd.DataFrame:
    """
    Извлекает основные признаки из временного ряда
    
    Args:
        df: DataFrame с данными OHLCV
        window_sizes: Размеры окон для расчета признаков
        
    Returns:
        DataFrame с извлеченными признаками
    """
    features = pd.DataFrame(index=df.index)
    
    # Добавляем логарифмические доходности
    features['log_return'] = np.log(df['close'] / df['close'].shift(1))
    
    # Для каждого размера окна
    for window in window_sizes:
        # Волатильность (стандартное отклонение доходности)
        features[f'volatility_{window}'] = features['log_return'].rolling(window=window).std()
        
        # Доходность за период
        features[f'return_{window}'] = df['close'] / df['close'].shift(window) - 1
        
        # Относительное положение цены к диапазону
        features[f'price_position_{window}'] = (df['close'] - df['low'].rolling(window=window).min()) / \
                                              (df['high'].rolling(window=window).max() - df['low'].rolling(window=window).min())
        
        # Объем относительно среднего объема
        features[f'volume_ratio_{window}'] = df['volume'] / df['volume'].rolling(window=window).mean()
        
        # Наклон тренда (линейная регрессия)
        x = np.arange(window)
        for i in range(window, len(df)):
            y = df['close'].iloc[i-window:i].values
            slope = np.polyfit(x, y, 1)[0]
            features.iloc[i, features.columns.get_loc(f'trend_slope_{window}')] = slope
    
    return features


def extract_technical_features(df: pd.DataFrame, with_indicators: bool = True) -> pd.DataFrame:
    """
    Извлекает признаки на основе технических индикаторов
    
    Args:
        df: DataFrame с данными OHLCV и техническими индикаторами
        with_indicators: Флаг, указывающий, содержит ли df уже индикаторы
        
    Returns:
        DataFrame с извлеченными признаками
    """
    features = pd.DataFrame(index=df.index)
    
    # Если индикаторы уже рассчитаны в исходном DataFrame
    if with_indicators:
        indicator_cols = [
            'sma_20', 'ema_20', 'rsi_14', 'macd', 'macd_signal', 'macd_hist',
            'bb_upper', 'bb_middle', 'bb_lower', 'stoch_k', 'stoch_d', 'atr_14'
        ]
        
        # Проверяем наличие нужных колонок
        missing_cols = [col for col in indicator_cols if col not in df.columns]
        if missing_cols:
            raise ValueError(f"В DataFrame отсутствуют необходимые индикаторы: {', '.join(missing_cols)}")
        
        # Вычисляем признаки на основе индикаторов
        
        # RSI - перекупленность/перепроданность
        features['rsi_overbought'] = (df['rsi_14'] > 70).astype(int)
        features['rsi_oversold'] = (df['rsi_14'] < 30).astype(int)
        
        # MACD - пересечение сигнальной линии
        features['macd_cross_above'] = ((df['macd'] > df['macd_signal']) & 
                                      (df['macd'].shift(1) <= df['macd_signal'].shift(1))).astype(int)
        features['macd_cross_below'] = ((df['macd'] < df['macd_signal']) & 
                                      (df['macd'].shift(1) >= df['macd_signal'].shift(1))).astype(int)
        
        # Bollinger Bands - положение цены относительно полос
        features['price_above_upper_bb'] = (df['close'] > df['bb_upper']).astype(int)
        features['price_below_lower_bb'] = (df['close'] < df['bb_lower']).astype(int)
        features['bb_width'] = (df['bb_upper'] - df['bb_lower']) / df['bb_middle']
        
        # Stochastic - пересечения и положения
        features['stoch_cross_above'] = ((df['stoch_k'] > df['stoch_d']) & 
                                       (df['stoch_k'].shift(1) <= df['stoch_d'].shift(1))).astype(int)
        features['stoch_cross_below'] = ((df['stoch_k'] < df['stoch_d']) & 
                                       (df['stoch_k'].shift(1) >= df['stoch_d'].shift(1))).astype(int)
        features['stoch_overbought'] = ((df['stoch_k'] > 80) & (df['stoch_d'] > 80)).astype(int)
        features['stoch_oversold'] = ((df['stoch_k'] < 20) & (df['stoch_d'] < 20)).astype(int)
        
        # Положение цены относительно скользящих средних
        features['price_above_sma'] = (df['close'] > df['sma_20']).astype(int)
        features['price_above_ema'] = (df['close'] > df['ema_20']).astype(int)
        
        # ATR как мера волатильности
        features['atr_ratio'] = df['atr_14'] / df['close']
    
    return features


def create_lagged_features(features: pd.DataFrame, lag_periods: List[int] = [1, 2, 3, 5, 10]) -> pd.DataFrame:
    """
    Создает лагированные признаки для машинного обучения
    
    Args:
        features: DataFrame с базовыми признаками
        lag_periods: Список периодов для создания лагов
        
    Returns:
        DataFrame с лагированными признаками
    """
    lagged_features = features.copy()
    
    # Для каждой колонки создаем лагированные версии
    for col in features.columns:
        for lag in lag_periods:
            lagged_features[f"{col}_lag_{lag}"] = features[col].shift(lag)
    
    return lagged_features


def create_target_variable(df: pd.DataFrame, horizon: int = 1, threshold: float = 0.0) -> pd.Series:
    """
    Создает целевую переменную для задачи прогнозирования
    
    Args:
        df: DataFrame с данными OHLCV
        horizon: Горизонт прогнозирования (количество периодов вперед)
        threshold: Пороговое значение для определения направления
        
    Returns:
        Series с целевыми значениями (1 - рост, 0 - падение)
    """
    # Расчет будущего изменения цены
    future_return = df['close'].shift(-horizon) / df['close'] - 1
    
    # Бинарная классификация: 1 если доходность > threshold, иначе 0
    target = (future_return > threshold).astype(int)
    
    return target